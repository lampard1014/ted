//
//  ViewController.swift
//  swiftLearn1
//
//  Created by 冯龙胜的Mac　 on 2018/7/25.
//  Copyright © 2018年 哥特复兴. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //  1.1) swift还是使用// 和/* */ 来注释,并且/* */允许多行注释.
    // 2.1) let 定义常量,var 定义变量,let定义的必须在声明时指定初始值,普通的var声明也必须赋初始值. let 声明的变量不可再改变,而var变量可以再改变,但是你不能再声明一个已经声明的常量或变量.
    //  1.2) swift使用print和println打印,它的传参是一个泛型,几乎所有类型都是可打印的.
    // 1.3) swift在语句后面加分号与否都是正确的,但是swift偏好的风格是不在结尾处加分号的.如果有多个语句,必须用分号隔开.
    // 1.4) 在一个数字中庸下划线(_)会被忽视,方便认出大数值的的数字,也可以在前面补零.
    // 1.5) swift不允许在不同种类型间做加减乘除,要先做类型转换或运算符重载.
    // Swift可以自动进行类型推导，根据后面的数值自动去推导前面变量或者常量的类型
    // swift的命名不能使用保留字和箭头/开头不能用数字,没有其它任何规定,甚至都可以使用小狗小猫命名.
    let height = 1_000_000
    let width = 00128400
    
    let x = 0.25; let a :Double = 3.14
    let y = 10
    
    // 类型别名 类型别名对当前的类型定义了另一个名字，类型别名通过使用 typealias 关键字来定义。语法格式如下： typealias newname = type
    typealias feed = Int
    let abc :feed = 23
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        learn1()
//        OptionalsLearn()
//        operationLearn()
//        literalLearn()
//        conditions()
//        cycleLearn()
//        arrayLearn()
        dictionaryLearn()
    }

    // swift 基础
    func learn1() {
        print("hello world")
        print("height-----",height)
        print("width-----",width)
//        let mun = x * y
        let num = x * Double(y)
        // 在Swift中，运算符不能直接跟在变量或常量的后面。例如下面的代码会报错：
//        let num1= x * Double(y)
        print(num)
        // 这是想在字符串中间插入某个变量的用法\(变量)
        print("你今年\(num)岁了")
        
        
        
    }
    
    // 可选类型(Optionals)
    func OptionalsLearn() {
        
        //Swfit语言定义后缀？作为命名类型Optional的简写，换句话说，以下两种声明是相等的：
//        var x :String = "nih"
//        print(x)
        var optionalInteger1: String?
//        var optionalInteger2: Optional<String>
        // 强制解析 当你确定可选类型确实包含值之后，你可以在可选的名字后面加一个感叹号（!）来获取值。这个感叹号表示"我知道这个可选有值，请使用它。"这被称为可选值的强制解析
        // 使用!来获取一个不存在的可选值会导致运行时错误。使用!来强制解析值之前，一定要确定可选包含一个非nil的值
        optionalInteger1 = "hello swift"
        if optionalInteger1 != nil {
            print(optionalInteger1!)
        }else{
            print("hello world")
        }
        
    }
    
    // Swift 字面量
    
    func literalLearn() {
        // 所谓字面量，就是指像特定的数字，字符串或者是布尔值这样，能够直接了当地指出自己的类型并为变量进行赋值的值。比如在下面：
        let aNumber = 3         //整型字面量
        let aString = "Hello"   //字符串字面量
        let aBool = true        //布尔值字面量
        // 整型字面量   整型字面量可以是一个十进制，二进制，八进制或十六进制常量。 二进制前缀为 0b，八进制前缀为 0o，十六进制前缀为 0x，十进制没有前缀：
        let decimalInteger = 17           // 17 - 十进制表示
        let binaryInteger = 0b10001       // 17 - 二进制表示
//        print(binaryInteger)
        let octalInteger = 0o21           // 17 - 八进制表示
        let hexadecimalInteger = 0x11     // 17 - 十六进制表示
        // 浮点型字面量  浮点型字面量允许使用下划线 _ 来增强数字的可读性，下划线会被系统忽略，因此不会影响字面量的值。同样地，也可以在数字前加 0，并不会影响字面量的值。
        let decimalDouble = 12.1875       //十进制浮点型字面量
        let exponentDouble = 1.21875e1    //十进制浮点型字面量
        let hexadecimalDouble = 0xC.3p0   //十六进制浮点型字面量
        
    }
    
    // Swift 运算符
    // Swift 提供了以下几种运算符  1.算术运算符 2.比较运算符  3.逻辑运算符  4.位运算符  5.赋值运算符  6.区间运算符  7.其他运算符
    func operationLearn() {
        /* 算术运算符**/
        // 依然采用 加(+)  减(-)  乘(*)  除(/) 求余(%)
        //注意：swift3 中已经取消了++、--。
        var A = 10
        var B = 20
        A += 1
        B -= 1
        
        /* 比较运算符**/
        // 依然采用 等于(==)  不等于(!=)  大于(>)  小于(<)  大于等于(>=)  小于等于(<=)
        
        /* 逻辑运算符**/
        // 依然采用 1.逻辑与(&&)  如果运算符两侧都为 true 则为 true  2.逻辑或(||)。 如果运算符两侧至少有一个为 true 则为 true  3.逻辑非(!)布尔值取反，使得true变false，false变true。
        
        /* 位运算符**/
        // 位运算符用来对二进制位进行操作，~,&,|,^分别为取反，按位与与，按位与或，按位与异或运算
        var X = 60  // 二进制为 0011 1100
        var Y = 13 //  二进制为 0000 1101
        /*按位与运算符对两个数进行操作，然后返回一个新的数，这个数的每个位都需要两个输入数的同一位都为1时才为1。*/
         print("X&Y 结果为：\(X&Y)")  // X&Y 12 结果为：0000 1100
        /*按位或。按位或运算符|比较两个数，然后返回一个新的数，这个数的每一位设置1的条件是两个输入数的同一位都不为0(即任意一个为1，或都为1)。*/
        print("X|Y 结果为：\(X|Y)")  // X|Y 61 结果为:0011 1101
        /*按位异或. 按位异或运算符^比较两个数，然后返回一个数，这个数的每个位设为1的条件是两个输入数的同一位不同，如果相同就设为0。*/
        print("X^Y 结果为：\(X^Y)")  //X^Y 49 结果为:0011 0001
        /*按位取反运算符~对一个操作数的每一位都取反。*/
        print("~X 结果为：\(~X)")    //~X -61 结果为:1100 0011
        
        /*赋值运算**/
        /* 1.简单的赋值运算，指定右边操作数赋值给左边的操作数。(=)
           2.相加后再赋值，将左右两边的操作数相加后再赋值给左边的操作数   (+=)
           3.相减后再赋值，将左右两边的操作数相减后再赋值给左边的操作数。 (-=)
           4.相乘后再赋值，将左右两边的操作数相乘后再赋值给左边的操作数。 (*=)
           5.相除后再赋值，将左右两边的操作数相除后再赋值给左边的操作数。 (/=)
           6.求余后再赋值，将左右两边的操作数求余后再赋值给左边的操作数。 (%=)
           7.按位左移后再赋值                                     (<<=)
           8.按位右移后再赋值                                     (>>=)
           9.按位与运算后赋值                                     (^=)
          10.按位或运算后再赋值                                    (|=)
         **/
        
        /*区间运算符**/
        //迭代一个区间的所有值时是非常有用的，如在for-in循环中：
        // 闭区间运算符
        
        print("闭区间运算符:")
        for index in 1...5 {
            print("\(index) * 5 = \(index * 5)")
        }
        
        print("半开区间运算符:")
        for index in 1..<5 {
            print("\(index) * 5 = \(index * 5)")
        }
        
        /*其他运算符**/
        // condition ? X : Y    如果 condition 为 true ，值为 X ，否则为 Y
        
        /*运算符优先级**/
        /* 1.指针最优，单目运算优于双目运算。如正负号。
           2.先乘除（模），后加减。
           3.先算术运算，后移位运算，最后位运算。请特别注意：1 << 3 + 2 & 7 等价于 (1 << (3 + 2))&7
           4.逻辑运算最后计算
         **/
    }
    
    // 条件语句
    func conditions() {
        // 很多和oc一样  只说区别
        let a = 3
        if a > 1 {
//            print("10086")
        } else {
//            print("10010")
        }
        
        // 注意：在大多数语言中，switch 语句块中，case 要紧跟 break，否则 case 之后的语句会顺序运行，而在 Swift 语言中，默认是不会执行下去的，switch 也会终止。如果你想在 Swift 中让 case 之后的语句会按顺序继续运行，则需要使用 fallthrough 语句。  如果使用了fallthrough 语句，则会继续执行之后的 case 或 default 语句，不论条件是否满足都会执行。
        switch a {
        case 3:
            print("OK1")
            fallthrough
        case 2:
            print("OK2")
        default:
            print("默认")
        }
        
    }
    
    // Swift 循环
    func cycleLearn() {
        // 循环类型
        // 1.for-in
        for index in 1...5 {
            print("\(index) 乘于 5 为：\(index * 5)")
        }
        
        var someInts:[Int] = [10, 20, 30]
        
        for (index, item) in someInts.enumerated() {
            print("index:\(index)  item：\(item)")
        }
        
        for index in someInts {
            print( "index 的值为 \(index)")
        }
        // 2. for循环(在swift3中被废弃)
        
        // 3.while循环
        var index1 = 10
        while index1 < 20
        {
            print( "index 的值为 \(index)")
            index1 = index1 + 1
        }
        // 4.repeat...while 循环
        /*
         Swift repeat...while 循环的语法格式如下:
         repeat
         {
         statement(s);
         }while( condition );
         */
        
        var index2 = 15
        repeat{
            print( "index 的值为 \(index)")
            index2 = index2 + 1
        }while index2 < 20
        
    }
    
    /*数组**/
    // Swift 数组使用有序列表存储同一类型的多个值。相同的值可以多次出现在一个数组的不同位置中。
    func arrayLearn() {
        // 以下实例创建了一个类型为 Int ，数量为 3，初始值为 0 的空数组：
        let someInts1 = [Int](repeating: 0, count: 3)
        print(someInts1)
//        someInts1.
        // 以下实例创建了含有三个元素的数组：
        var someInts2:[Int] = [10, 20, 30]
        // 访问数组
        let someVar = someInts2[1]
        print(someVar)
        
        // 修改数组
    /*你可以使用 append() 方法或者赋值运算符 += 在数组末尾添加元素，如下所示，我们初始化一个数组，并向其添加元素*/
        var someInts3 = [Int]()
        print("oldsomeInts3 = ",someInts3)
        someInts3.append(1)
        someInts3.append(2)
        someInts3 += [3,4,5]
        print("newsomeInts3 = ",someInts3)
        // 修改最后一个元素
        someInts3[2] = 5
        print(someInts3)
        
        // 遍历数组  可以使用for-in循环来遍历所有数组中的数据
        for item in someInts3 {
            print(item)
        }
        // 如果同时需要每个数据项的值和索引值，可以使用 String 的 enumerate() 方法来进行数组遍历
        for (index, item) in someInts3.enumerated() {
            print("在 index = \(index) 位置上的值为 \(item)")
        }
        
        // 合并数组  可以使用加法操作符（+）来合并两种已存在的相同类型数组
        let intsA:[Int] = [10,20,30,40]
        let intsB:[Int] = [50,60,70,80]
        
        let intsC = intsA + intsB
        for intX in intsC {
            print(intX)
        }
        
        // 当然我们要想得到一个数组的数量的话 还是可以用count属性
        // swift 可以使用isEmpty 属性判断数组是否为空
        print("intsA.isEmpty = \(intsA.isEmpty)")
        if intsA.isEmpty {
            print("intsA数组为空")
        }else{
            print("intsA数组不为空")
        }
        
    }
    
    /*Swift 字典**/
    //字典用来存储无序的相同类型数据的集合，Swift 字典会强制检测元素的类型，如果类型不同则会报错。
    func dictionaryLearn() {
        // Swift 字典的key没有类型限制可以是整型或字符串，但必须是唯一的。
        let someDict1:[Int:String] = [1:"10086",2:"10010"]
        print(someDict1)
        
        
        let someDict2:[String:String] = ["name":"冯龙胜","age":"26"]
        print(someDict2)
        
        // 访问字典
        let someVar1 = someDict1[1]
        let someVar2 = someDict2["name"]
        print(someVar1)
        print(someVar2)
        
        // 修改字典
        var oldDict:[String:String] = ["name":"小明","age":"26","height":"178"]
        print(oldDict)
        oldDict["height"] = "175"
        print(oldDict)
        // 添加新的键值对
        oldDict["width"] = "65"
        print(oldDict)
        
        // 删除键值对
        oldDict.removeValue(forKey: "age")
        print(oldDict)
        // 当然也可以通过指定键的值为 nil 来移除 key-value（键-值）对
        oldDict["width"] = nil
        print(oldDict)
        
        // 遍历字典
        // 我们可以使用 for-in 循环来遍历某个字典中的键值对。
        var someDict4:[Int:String] = [1:"One", 2:"Two", 3:"Three"]
        for (key, value) in someDict4 {
            print("字典 key \(key) -  字典 value \(value)")
        }
        
        // 字典转换为数组
        var newDict:[Int:String] = [2:"Two",1:"One", 3:"Three"]
        let keys = [Int](newDict.keys)
        let values = [String](newDict.values)
        
        for key in keys {
            print(key)
        }
        
        for value in values {
            print(value)
        }
        
        // 同理  我们也可以使用count 属性来获取字典中有多少键值对
        print("someDict1 含有 \(newDict.count) 个键值对")
        
        // isEmpty 属性  我们可以通过只读属性 isEmpty 来判断字典是否为空
        print("someDict1 = \(newDict.isEmpty)")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

