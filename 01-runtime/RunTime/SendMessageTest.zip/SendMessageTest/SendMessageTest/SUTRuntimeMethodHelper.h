//
//  SUTRuntimeMethodHelper.h
//  备用接受者测试
//
//  Created by 刘华健 on 15/7/18.
//  Copyright (c) 2015年 MK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SUTRuntimeMethodHelper : NSObject


- (void)method1;
- (void)method2;
- (void)method3:(NSInteger)index;
@end
